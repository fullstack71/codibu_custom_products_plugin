<?php
defined('ABSPATH') || die ("You can't access this file directyly !");
require(spin_wheel_dir."/oopspk_spin_wheel_for_woocommerce_setting_page.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_woocommerce_functions.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_add_car_vin_number.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_add_field_to_woocommerce_checkout.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_select_car_bin_number.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_order_invoice.php");
require(spin_wheel_dir."/oopspk_spin_wheel_for_add_car_status_in order_details.php");
?>

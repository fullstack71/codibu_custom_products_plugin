==== Woocommerce Modify Products Management ====
Contributors: oops.pk
Tags: Woocommerce Variations ,Woocommerce Modify Products Management.
Requires at least: 4.9
Tested up to: 6.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



=== Description ===

The plugin “Woocommerce Modify Products Management.” enables you to customize your WooCommerce products’ variations. 

There is no need to navigate to different pages, you can manage the customization of the variations of products from a single page.

Save your precious time using this plugin and edit and manage the products’ variations instantaneously and efficiently.

Features:
Woocommerce Easy Variations Management Features
Control and manage the products’ variations from one page.
Add, edit, and sort, and remove the variations.
Users can add tax classes through variation management. 
Add featured images to each variation of the products.
Users have the power to manage the stock quantity.
It enables the users to add the regular price of the product.
Manage weight in Kilograms.
Set multiple dimensions (length, width, height) in inches.
Enables the variation settings on the product edit page from the backend.
Users can hide the variation management tab.

=== Installation ===

How does it work?
The plugin “Woocommerce Modify Products Management.” requires simple and easy steps to configure.

Install and activate the plugin from WordPress.
Navigate WooCommerce → Woocommerce Modify Products Management.
Select the product from the drop-down menu.
Manage the products’ variation.
Also, navigate the WooCommerce → Products → Settings tab and tick the first option.
Edit the variations from the Edit Variations page.
Change the tax classes from the tax class option.

=== Instructions ===
The plugin “Woocommerce Modify Products Management.” requires simple and easy steps to configure.




